import React from 'react'
import TrainerList from '../containers/Trainer-List'
import TrainerDetails from '../containers/Trainer-Details'

const App = ()=>{
    return(
        <div>
            <TrainerList/>
            <TrainerDetails/>
        </div>
    )
}

export default App;