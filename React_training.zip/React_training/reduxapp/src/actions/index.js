export const selectTrainer=(trainer)=>{
    console.log("You have clicked on trainer",trainer.id)
    //CRUD to invoke REST services
    //Axios.get() or middleware
    //$.ajax(url,)
    //fetch(url)
    return{
        type:"TRAINER_SELECTED",
        payload:trainer
    }
}