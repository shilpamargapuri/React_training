import {combineReducers} from 'redux'
import TrainerReducer from './Reducer-Trainers'
import ActiveTrainerReducer from './Reducer-Active-Trainer'

const allReducers = combineReducers({
    trainers:TrainerReducer,
    activeTrainer:ActiveTrainerReducer
})
export default allReducers