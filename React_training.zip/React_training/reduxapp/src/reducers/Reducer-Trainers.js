import data from '../store/Store'

export default (state=null,action)=>{
    //returning initial state of trainer list
    return state=data;//Mocked data
}