import React from 'react'
export default class LanguagesKnown extends React.Component{
    
}