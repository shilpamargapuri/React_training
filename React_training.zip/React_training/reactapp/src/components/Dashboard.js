import React, { Component } from 'react';
import StatefulApp from './props-states/StatefulApp';
import Grid from './props-states/Grid';
import Textinput from './props-states/Textinput';
import ChildParentInvoke from './parent-child/ChildParentInvoke';
import UsingRefs from './parent-child/UsingRefs'
import Context from './context-api/Context';
import WeatherComponent from './component-lifecycle/WeatherComponent';
import FormApp from './formvalidation/FormApp'
import MyHOC from './HOC/HOC'
import ButtonOne from './ButtonOne'


//stateful functional component (class component)
export default class Dashboard extends Component {
    constructor(props){
        super(props);
        this.state={};
    }

    //this is stateful because we have written everything in render, if we directly return something it is SFC.
    render(){
        return(
            <div>
                {/* <StatefulApp/>
                <Grid/>
                <Textinput/> 
                <ChildParentInvoke />
                <UsingRefs/>
                <Context/>
                <CompLifeCycle/>
                <WeatherComponent/>
                <FormApp/>*/}
                <MyHOC/>
                <ButtonOne/>
                <ButtonOne disable />
                <ButtonOne blueBG />
            </div>
        )
    }
}