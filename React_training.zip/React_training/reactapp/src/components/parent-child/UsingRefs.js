import React, { Component } from 'react';
import ReactDOM from 'react-dom';
import AddColorForm from './AddColorForm';

//import AddColorForm from './AddColorForm'
export default class UsingRefs extends React.Component{
    constructor(props){
        super(props);

        //this.props.x="hello" not allowed as props are immutable
        this.state={
            data:'Hello'
        }
        this.updateState=this.updateState.bind(this);
        this.clearInput=this.clearInput.bind(this);
    };

    updateState(e){
        this.setState({data:e.target.value});
    }

    clearInput(){
        this.setState({data:''});
        alert(this.refs.myInput.value);
        this.refs.myInput.focus();
        console.log(this.refs.myInput.value);
        this.refs.myInput.value='';
        console.log(this.refs.myInput.value);
    }

    render(){
        return (
            <div>
                Name:<input value={this.state.data}
                onChange = {this.updateState}
                ref = "myInput" id="text1"/>

                <button onClick={this.clearInput}>CLEAR</button>
                <h4>{this.state.data}</h4>
                <AddColorForm/>
            </div>
        )
    }
}