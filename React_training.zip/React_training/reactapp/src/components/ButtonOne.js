import React, { Component } from 'react'
import StylesWrapper from './HOC/StylesWrapper'

const ButtonOne = (props) =>{
    return(
        <button style={props.styles}>Click me</button>
    )
}
export default StylesWrapper(ButtonOne)