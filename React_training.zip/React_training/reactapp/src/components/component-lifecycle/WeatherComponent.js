import React, { Component } from 'react'
class WeatherComponent extends React.Component{
    constructor(props){
        super(props)
        this.state={
            weather:'sunny',
            pictures:[]
        }
    }

    componentDidMount(){
        console.log("inside componentDidMount method");

        //REST call
        fetch('https://randomuser.me/api/?results:100')
            .then(results=>{
                return results.json();
            }).then(data=>{
                let pictures=data.results.map(pic=>{
                    return(
                        <div key={Math.random()}>
                            <img src={pic.picture.medium}/>
                        </div>
                    )
                })
                this.setState({pictures:pictures})
                console.log("state",this.state.pictures)
            })
    }
    changeName(e){
        console.log("change name called");
        this.setState({weather:'Rainy'})
    }
    render(){
        console.log("inside render function");
        return(
            <div>
                <h1>Today, the weather is:{this.state.weather}</h1>
                <button onClick={(e)=>this.changeName(e)}>Change weather to rainy</button>
                <span>{this.state.pictures}</span>
            </div>
        )
    }
}
export default WeatherComponent;