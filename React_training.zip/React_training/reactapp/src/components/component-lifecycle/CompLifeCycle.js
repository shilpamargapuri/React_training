import React, { Component } from 'react'
import { nextTick } from 'q';

export default class CompLifeCycle extends React.Component{
    constructor(props){
        //1. initialization phase
        super(props);
        this.state={
            data:0,
            msg:'Initial data...'
        }
        //this.setNewNumber = this.setNewNumber.bind(this);
        //this.updateState = this.updateState.bind(this);
    }

    setNewNumber(e){
        this.setState({data:this.state.data+1});
    }
    updateState(e){
        this.setState({msg:e.target.value});
    }


    //2. Initial render
    render(){
        return(
            <div>
                <button onClick = {(event)=>{this.setNewNumber(event)}}>Increment</button>
                <Content myNumber={this.state.data}></Content>
                <br/>
                <input type="text" value={this.state.msg}
                    onChange ={(event)=>this.updateState(event)} />
                    <h3>{this.state.msg}</h3>
            </div>
        )
    }
}//parent component is completed


//child component
class Content extends React.Component{
    constructor(props){
        //Initialize props with constructor, initialize state and register events
        super(props);
        this.state={name:'Murthy'}
        console.log("In Constructor:"+props.myNumber);
        console.log("1.Content constructor fired - initialization phase");
        this.handleScroll=this.handleScroll.bind(this);
    }
    //register the handler
    handleScroll(){
        console.log("handle scroll is executed")
    }

    //The componentWillMount() method is invoked only once before initial rendering.
    // It is also a good place to set initial state value inside componentWillMount()
    componentWillMount(){
        //load data from cache(local storage)
        console.log("1. componentWillMount=>"+ this.props.myNumber);
    }

    //important hook-> fires only once
    componentDidMount(){
        console.log("2.Component DID Mount!- reset data or reinitialize data");
        console.log("componentDidMount=>"+ this.props.myNumber);
        //Make ajax calls here or load some mocked data and update state
        //window.addEventListener("scroll",this.handleScroll);
    }
    componentWillReceiveProps(nextProps){
        //This method will be invoked when a component is receiving new props. 
        //componentWillReceiveProps() won't be called for the initial rendering.
        console.log("3. set default props here and validate props here");
        console.log("props in component will receive:"+nextProps.myNumber);
        //the old props can be accessed via this.props inside this.
        //you can set state according to changes of props in this method.
        this.setState({
            isPassed:nextProps.myNumber >=60
        });
    }

    //In future versions, above method is replaced with below method
    static getDerivedStateFromProps(props, state){
        console.log("getDerivedStateFromProps");
        console.log(state.name)
        return {}
        //only state management
    }

    //shouldComponentUpdate() will be invoked before rendering
    //when new props or state are being received.
    //this method won't be called on initial rendering. (return true by default)
    shouldComponentUpdate(nextProps,nextState){
        //rendering management
        console.log("Decide whether to re-render or not");
        console.log(nextState);

        console.log("4. Component is rendered");
        if(nextProps.myNumber>3){
            return true
        }
        else{
            return false; // change it to false to stop rendering 
        }
    }

    //use this as an opportunity to prepare for an update.
    componentWillUpdate(nextProps, nextState){
        //check props and state before updating state
        console.log("5. Component will update!"+nextProps.myNumber);
    }

    //this method is not called for initial rendering
    //you can perform DOM operations here
    //access real DOM with jquery here or normal javascript
    componentDidUpdate(prevProps, prevState){
        console.log("7. Component DID update! - you can rollback state here to previous state")
    }

    //error handling only available from 16.0 onwards
    componentDidCatch(err){
        console.log("some error has occured...log it in server")
    }
    

    //this is invoked immediately before a component is unmounted or removed from DOM
    //use this as an opportunity to perform cleanup operations
    //for example, unbind event listeners here to avoid memory leaking
    componentWillUnmount(){
        console.log("8. Component will UNMOUNT!-release the resources here or cache data");
        window.removeEventListener("scroll",this.handleScroll);
    }
    render(){
        return(
            <div>
                <h3>{this.props.myNumber}</h3>
            </div>
        )
    }
}