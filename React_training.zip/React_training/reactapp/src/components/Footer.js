import React from 'react';
//SFC= Stateless Functional Component
export const Footer=()=>{
    return(
        <div>
            <h4 className="bg-warning text-center">Copyright reserved</h4>
        </div>
    );
}
