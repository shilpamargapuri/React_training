import React from 'react';
export function Login(props){
    return(
        <h3><a href="http:\\www.verizon.com">Login to {props.portal}, {props.subPortal}</a></h3>
    )
}