import React from 'react';
import logo from './logo.svg';
import './App.css';
import {Header} from './components/Header';
import {Footer} from './components/Footer';
import {Login} from './components/Login';
import Dashboard from './components/Dashboard';

function App() {
  return (
    <div className="App">
      <header className="">
        <img src={logo} className="App-logo" alt="logo" width="150" height="150"/>
        <h1 className="App-title">React & Redux</h1>
      </header>
      <Header title="React SPA Project"></Header>
      <Login portal="Verizon" subPortal="wireless"></Login>
      {/* <h1>Put your components here</h1> */}
      <Dashboard/>
      <Footer/>
    </div>
  );
}

export default App;
