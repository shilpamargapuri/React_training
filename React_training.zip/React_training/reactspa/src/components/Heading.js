import React, { Component } from 'react';
export const Heading = () => {
    return (
      <div className="head">
       <h1>React SPA by Shilpa</h1>
      </div>
    );
}
