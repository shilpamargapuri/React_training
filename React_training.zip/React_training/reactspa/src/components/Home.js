import React  from 'react';
export const  Home=()=> {  
    return (
      <div>
       <h1>Welcome to Cars Management Project</h1>
       <h3>shilpa.margapuri@verizon.com</h3>
      </div>
    );
  }




