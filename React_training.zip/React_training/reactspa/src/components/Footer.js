import React, { Component } from 'react';
export const Footer =()=> {
    return (
        <div>
        <h3 className="footer">Copyright Reserved</h3>
        </div>
    );
}



