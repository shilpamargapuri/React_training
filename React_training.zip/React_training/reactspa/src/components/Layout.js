import React, { Component } from 'react';
import {Route, Link, Switch} from 'react-router-dom'
import {Home} from './Home'
import {Customers} from './Customers'
import {Login} from './Login'
import Cars from './Cars'
import {CarDetails} from './CarDetails'
import {Greet} from './Greet'

export const Layout = ()=>(
    <div className="layoutContainer">
        <nav className="nav">
            <Link className="navItem" exact to="/">Home</Link>
            <Link className="navItem" exact to='/users'>Customers</Link>
            <Link className="navItem" exact to='/cars'>Cars</Link>
            <Link className="navItem" exact to='/login'>Login</Link>
            <Link className="navItem" exact to='/greet/Shilpa'>Greet</Link>

        </nav>

        <main className="container">
            <Switch>
                <Route path="/" exact component={Home}></Route>
                <Route path="/users" component={Customers}></Route>
                <Route path="/login" component={Login}></Route>
                <Route path="/cars" component={Cars}></Route>
                <Route path="/carDetails/:carId" component={CarDetails}/>
                <Route path="/greet/:username" render={(props)=>(<Greet{...props}/>)} ></Route>

                <Route component={NotFound} />
            </Switch>
        </main>
    </div>
)

const NotFound=()=> <div>Sorry, page not found!</div>
