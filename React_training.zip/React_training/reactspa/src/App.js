import React from 'react';
import logo from './logo.svg';
import './App.css';
import {Heading} from './components/Heading'
import {Footer} from './components/Footer'
import {Layout} from './components/Layout'

function App() {
  return (
    <div className="App">
      <Heading/>
      <div>
        <Layout/>
      </div>
      <Footer/>
    </div>
  );
}

export default App;
