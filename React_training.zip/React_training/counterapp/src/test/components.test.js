import React, { Component } from 'react'
import renderer from 'react-test-renderer'
import App from '../App'

describe('components testing',function(){
    describe('App testing', () => {
        it('renders correctly', () => {
            var domtree=renderer.create(<App/>).toJSON();
            expect(domtree).toMatchSnapshot()
        });
    });
})