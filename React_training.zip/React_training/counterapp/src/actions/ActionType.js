export const ADD_COUNTER='ADD_COUNTER';
export const REMOVE_COUNTER='REMOVE_COUNTER';

//Magical string is anti-pattern