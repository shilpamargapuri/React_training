import * as actionType from './ActionType'
import {SAVE_COMMENT} from './types'
import { types } from '@babel/core';

export const addCounter = (newvalue)=>({
    type:actionType.ADD_COUNTER,
    payload:newvalue
})

export const removeCounter = (newvalue)=>({
    type:actionType.REMOVE_COUNTER,
    payload:newvalue
})

export const saveComment = (comment)=>({
    type:SAVE_COMMENT,
    payload:comment
})